/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.util.ArrayList;

/**
 *
 * @author Clarissa
 */
public class MaestroDetalle {
    
  private ArrayList<Producto>lDatosProd;

   private String NomCliente;
   private int producComprados;
   

    public MaestroDetalle(ArrayList<Producto> lDatosProd) {
        this.lDatosProd = lDatosProd;
       
       
    }

    /**
     * @return the lDatosProd
     */
    public ArrayList<Producto> getlDatosProd() {
        return lDatosProd;
    }

    /**
     * @param lDatosProd the lDatosProd to set
     */
    public void setlDatosProd(ArrayList<Producto> lDatosProd) {
        this.lDatosProd = lDatosProd;
    }

    

   
   
   
    
     

 
  
  
  
  
}
